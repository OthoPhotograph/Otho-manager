# Otho Photograph Business Manager

Starter project Android native (Kotlin) untuk pencatatan penjualan offline.

## Membuka project
1. Instal Android Studio versi terbaru.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder `OthoPhotographAndroid`.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).

APK hasil build biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur yang sudah ada pada starter
- Database lokal Room (offline).
- Catat transaksi dengan pelanggan, jasa, jumlah, harga, dan modal.
- Hitung omzet dan keuntungan kotor otomatis.
- Daftar transaksi dan menu jasa.
- Ekspor riwayat ke CSV untuk dibuka di Excel.

## Fitur tahap lanjutan
Pemindai kamera/OCR, lampiran foto bukti, PDF/struk, backup-pemulihan, dan filter laporan periode masih perlu diimplementasikan dan diuji sebelum aplikasi dipakai untuk pembukuan sungguhan. Dependensi ML Kit OCR sudah disiapkan sebagai dasar.

## Catatan
Starter ini adalah kode sumber awal, bukan APK siap pasang. Perlu dibuild dan diuji di Android Studio. Simpan backup data secara berkala.
