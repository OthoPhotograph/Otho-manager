package id.othophotograph.business

import android.content.Context
import androidx.room.*

@Entity(tableName = "transactions")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val customer: String,
    val item: String,
    val qty: Int,
    val price: Long,
    val cost: Long,
    val note: String = "",
    val proofPath: String = ""
) {
    val revenue get() = qty * price
    val profit get() = qty * (price - cost)
}

@Entity(tableName = "services")
data class ServiceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val price: Long,
    val cost: Long
)

@Dao
interface SaleDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    suspend fun all(): List<Sale>
    @Insert suspend fun insert(sale: Sale)
    @Query("DELETE FROM transactions") suspend fun clear()
}
@Dao
interface ServiceDao {
    @Query("SELECT * FROM services ORDER BY name")
    suspend fun all(): List<ServiceItem>
    @Insert suspend fun insert(item: ServiceItem)
    @Query("DELETE FROM services WHERE id=:id") suspend fun delete(id: Long)
}

@Database(entities = [Sale::class, ServiceItem::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun sales(): SaleDao
    abstract fun services(): ServiceDao
    companion object {
        @Volatile private var INSTANCE: AppDb? = null
        fun get(context: Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, AppDb::class.java, "otho_business.db")
                .build().also { INSTANCE = it }
        }
    }
}
