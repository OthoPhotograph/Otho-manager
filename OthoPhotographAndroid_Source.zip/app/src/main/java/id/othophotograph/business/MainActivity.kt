package id.othophotograph.business

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val gold = Color.rgb(213, 176, 99)
    private val bg = Color.rgb(18, 18, 18)
    private val white = Color.WHITE
    private lateinit var db: AppDb
    private lateinit var body: LinearLayout
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("in", "ID"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AppDb.get(this)
        showHome()
    }

    private fun base(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(20, 24, 20, 16)
        }
        val heading = TextView(this).apply {
            text = "OTHO PHOTOGRAPH\n$title"
            textSize = 22f
            setTextColor(gold)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 20)
        }
        root.addView(heading)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(body) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(text: String, size: Float = 16f) {
        body.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            setPadding(0, 8, 0, 8)
        })
    }

    private fun button(text: String, action: () -> Unit) {
        body.addView(Button(this).apply {
            this.text = text
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
            setOnClickListener { action() }
        })
    }

    private fun field(hint: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            setSingleLine(true)
        }
        body.addView(e)
        return e
    }

    private fun showHome() {
        base("BUSINESS MANAGER")
        label("Kelola transaksi, jasa, pelanggan, dan keuntungan.", 14f)
        button("＋ Catat penjualan") { showNewSale() }
        button("Daftar transaksi") { showSales() }
        button("Menu jasa / produk") { showServices() }
        button("Laporan keuntungan") { showReport() }
        button("Ekspor CSV") { exportCsv() }
        lifecycleScope.launch {
            val sales = db.sales().all()
            val revenue = sales.sumOf { it.revenue }
            val profit = sales.sumOf { it.profit }
            label("RINGKASAN", 18f)
            label("Total omzet: ${rupiah.format(revenue)}")
            label("Estimasi keuntungan: ${rupiah.format(profit)}")
            label("Jumlah transaksi: ${sales.size}")
        }
    }

    private fun showNewSale() {
        base("CATAT PENJUALAN")
        val customer = field("Nama pelanggan")
        val item = field("Nama jasa / produk")
        val qty = field("Jumlah")
        val price = field("Harga jual per item (angka)")
        val cost = field("Modal per item (angka)")
        val note = field("Catatan (opsional)")
        button("Simpan transaksi") {
            val q = qty.text.toString().toIntOrNull()
            val p = price.text.toString().toLongOrNull()
            val c = cost.text.toString().toLongOrNull()
            if (customer.text.isBlank() || item.text.isBlank() || q == null || p == null || c == null || q <= 0) {
                Toast.makeText(this, "Lengkapi nama, jumlah, harga, dan modal dengan benar.", Toast.LENGTH_LONG).show()
            } else lifecycleScope.launch {
                db.sales().insert(Sale(customer=customer.text.toString(), item=item.text.toString(),
                    qty=q, price=p, cost=c, note=note.text.toString()))
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Transaksi tersimpan.", Toast.LENGTH_SHORT).show()
                    showHome()
                }
            }
        }
        button("Kembali") { showHome() }
    }

    private fun showSales() {
        base("RIWAYAT TRANSAKSI")
        lifecycleScope.launch {
            val list = db.sales().all()
            if (list.isEmpty()) label("Belum ada transaksi.")
            list.forEach {
                label("${it.customer} • ${it.item} x${it.qty}\nOmzet ${rupiah.format(it.revenue)} | Untung ${rupiah.format(it.profit)}", 14f)
            }
        }
        button("Kembali") { showHome() }
    }

    private fun showServices() {
        base("MENU JASA / PRODUK")
        val name = field("Nama jasa / produk")
        val price = field("Harga jual (angka)")
        val cost = field("Modal (angka)")
        button("Tambah menu") {
            val p = price.text.toString().toLongOrNull()
            val c = cost.text.toString().toLongOrNull()
            if (name.text.isBlank() || p == null || c == null) {
                Toast.makeText(this, "Isi nama, harga, dan modal.", Toast.LENGTH_SHORT).show()
            } else lifecycleScope.launch {
                db.services().insert(ServiceItem(name=name.text.toString(), price=p, cost=c))
                runOnUiThread { showServices() }
            }
        }
        lifecycleScope.launch {
            db.services().all().forEach { label("${it.name} • Jual ${rupiah.format(it.price)} • Modal ${rupiah.format(it.cost)}") }
        }
        button("Kembali") { showHome() }
    }

    private fun showReport() {
        base("LAPORAN KEUNTUNGAN")
        lifecycleScope.launch {
            val list = db.sales().all()
            label("Omzet: ${rupiah.format(list.sumOf { it.revenue })}")
            label("Modal tercatat: ${rupiah.format(list.sumOf { it.qty * it.cost })}")
            label("Keuntungan kotor: ${rupiah.format(list.sumOf { it.profit })}")
            label("Jumlah transaksi: ${list.size}")
            label("Catatan: biaya operasional belum dikurangkan.")
        }
        button("Kembali") { showHome() }
    }

    private fun exportCsv() {
        lifecycleScope.launch {
            val list = db.sales().all()
            val csv = buildString {
                append("Tanggal,Pelanggan,Jasa,Jumlah,Harga,Modal,Omzet,Keuntungan\n")
                list.forEach {
                    append("${it.date},\"${it.customer}\",\"${it.item}\",${it.qty},${it.price},${it.cost},${it.revenue},${it.profit}\n")
                }
            }
            val file = java.io.File(cacheDir, "otho_laporan.csv")
            file.writeText(csv)
            val uri = androidx.core.content.FileProvider.getUriForFile(
                this@MainActivity, "$packageName.provider", file
            )
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/csv"; putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(intent, "Bagikan laporan"))
        }
    }
}
